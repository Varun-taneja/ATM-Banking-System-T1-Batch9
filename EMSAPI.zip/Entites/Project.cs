﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace EMSAPI.Entites
{
    public class Project
    {
        [Key] //applies primary key to ProjectCode
        [Column(TypeName ="char")]
        [StringLength(5)] //size of the column
        public string ProjectCode { get; set; }
        [Required] //applies not null constraint
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string ProjectName { get; set; }
        //public string TeamSize { get; set; }

    }
}
