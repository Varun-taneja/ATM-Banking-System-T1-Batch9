﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace EMSAPI.Entites
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)] //disable identity
        public int Id { get; set; }
        [Required] //applies not null constraint
        [Column(TypeName = "varchar")]
        [StringLength(50)]
        public string Name { get; set; }
        public int? Salary { get; set; } //applied null
        [Column(TypeName = "char")]
        [StringLength(5)] //size of the column
        [ForeignKey("Project")]
        public string ProjectCode { get; set; }  
      public Project? Project { get; set; } //Navigatation Prop
    }
}
