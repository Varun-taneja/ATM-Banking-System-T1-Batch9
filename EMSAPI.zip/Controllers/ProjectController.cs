﻿using EMSAPI.Entites;
using EMSAPI.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectService projectService;

        public ProjectController(IProjectService projectService)
        {
            this.projectService = projectService;
        }
        //Endpoints
        [HttpPost,Route("AddProject")]
        public IActionResult Add(Project project)
        {
            try
            {
                projectService.AddProject(project);
                return StatusCode(200, project);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
