﻿using EMSAPI.Entites;
using EMSAPI.Models;

namespace EMSAPI.Service
{
    public interface IEmployeeService
    {
        void AddEmployee(Employee employee);
        List<Employee> GetEmployees();
        Employee GetEmployee(int id);
        void EditEmployee(Employee employee);
        void DeleteEmployee(int id);
        List<EmployeeModel> GetEmployeeswithProject();
    }
}
