﻿using EMSAPI.Entites;

namespace EMSAPI.Service
{
    public interface IProjectService
    {
        void AddProject(Project project);
    }
}
