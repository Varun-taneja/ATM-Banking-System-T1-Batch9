﻿using EMSAPI.Entites;
using EMSAPI.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EMSAPI.DTOS;
namespace EMSAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            this.employeeService = employeeService;
        }
        [HttpPost,Route("AddEmployee")]
        public IActionResult Add(EmployeeDTO employeeDTO)
        {
            try
            {
                Employee employee = new Employee()
                {
                    Id = employeeDTO.Id,
                    Name = employeeDTO.Name,
                    Salary = employeeDTO.Salary,
                    ProjectCode = employeeDTO.ProjectCode,
                };
                employeeService.AddEmployee(employee);
                return StatusCode(200, employeeDTO);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet,Route("GetEmployeesWithProject")]
        public IActionResult GetEmployeesWithProject()
        {
            return Ok(employeeService.GetEmployeeswithProject());
        }
    }
}
