﻿using Microsoft.EntityFrameworkCore;
namespace EMSAPI.Entites
{
    public class EMSDB89DBContext:DbContext
    {
        //public UworldDBContext(DbContextOptions<UworldDBContext> options):base(options)
        //{
            
        //}
        //Entity sets
        public DbSet<Project> Projects { get; set; }
        public DbSet<Employee> Employees { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"server=DESKTOP-4O1D65I\SQLEXPRESS;database=EMSDB89;trusted_connection=true");
        }
    }
}
