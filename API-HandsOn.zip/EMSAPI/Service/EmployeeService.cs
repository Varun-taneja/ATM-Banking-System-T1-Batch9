﻿using EMSAPI.Entites;
using EMSAPI.Models;

namespace EMSAPI.Service
{
    public class EmployeeService:IEmployeeService
    {
        private readonly EMSDB89DBContext _dbconteact;

        public EmployeeService(EMSDB89DBContext dbconteact)
        {
            _dbconteact = dbconteact;
        }

        public void AddEmployee(Employee employee)
        {
            _dbconteact.Employees.Add(employee);
            _dbconteact.SaveChanges();
        }
        public void DeleteEmployee(int id)
        {
            Employee employee = _dbconteact.Employees.Find(id);
            _dbconteact.Employees.Remove(employee);
            _dbconteact.SaveChanges();

        }
        public void EditEmployee(Employee employee)
        {
            _dbconteact.Employees.Update(employee);
            _dbconteact.SaveChanges();
        }

        public Employee GetEmployee(int id)
        {
            Employee employee = _dbconteact.Employees.Find(id);
            return employee;
        }

        public List<Employee> GetEmployees()
        {
            return _dbconteact.Employees.ToList();
        }

        public List<EmployeeModel> GetEmployeeswithProject()
        {
            try
            {
                List<EmployeeModel> employeeModels = (from e in _dbconteact.Employees
                                                      join p in _dbconteact.Projects
                                                      on e.ProjectCode equals p.ProjectCode
                                                      select new EmployeeModel()
                                                      {
                                                          Id = e.Id,
                                                          Name = e.Name,
                                                          Project = p.ProjectName
                                                      }).ToList();
                return employeeModels;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
