﻿using EMSAPI.Entites;

namespace EMSAPI.Service
{
    public class ProjectService : IProjectService
    {
        private readonly EMSDB89DBContext _dbContext;

        public ProjectService(EMSDB89DBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public void AddProject(Project project)
        {
           _dbContext.Projects.Add(project);
            _dbContext.SaveChanges();
        }
    }
}
