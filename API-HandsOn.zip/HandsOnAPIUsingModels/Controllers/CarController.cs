﻿using HandsOnAPIUsingModels.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HandsOnAPIUsingModels.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarController : ControllerBase
    {
        private CarRepository _carRepository;
        //public CarController()
        //{
        //    this._carRepository = new CarRepository();
        //}

        public CarController(CarRepository carRepository)
        {
            _carRepository = carRepository;
        }

        //Endpoints
        [HttpGet,Route("GetCars")]
        public IActionResult GetCars()
        {
            try
            {
                List<Car> cars=_carRepository.GetCars();
              return StatusCode(200, cars); //here cars details send in json form
              // return Ok(cars);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }
        [HttpGet,Route("GetCar/{model}")]
        public IActionResult GetCar(string model)
        {
            try
            {
                Car car = _carRepository.GetCar(model);
                if (car != null)
                    return StatusCode(200, car);
                else
                    return StatusCode(404, "Model car is not found");
            }
            catch (Exception ex)
            {

                return StatusCode(500, ex.Message);
            }
        }
        [HttpPost,Route("AddCars")]
        public IActionResult AddCar(Car car)
        {
            try
            {
                _carRepository.AddCar(car);
                return StatusCode(200, car);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpDelete,Route("DeleteCar/{model}")]
        public IActionResult Delete(string model)
        {
            _carRepository.DeleteCar(model);
            return StatusCode(200, new JsonResult($"{model} Car Deleted"));
        }
    }
}
