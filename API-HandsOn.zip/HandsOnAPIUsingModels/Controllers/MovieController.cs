﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HandsOnAPIUsingModels.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly Movie movie;

        public MovieController(Movie movie)
        {
            this.movie = movie;
        }
        [HttpGet,Route("Details")]
        public IActionResult Details()
        {
            return Ok(this.movie.Title);
        }
    }
}
