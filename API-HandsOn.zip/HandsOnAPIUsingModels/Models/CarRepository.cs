﻿namespace HandsOnAPIUsingModels.Models
{
    public interface ICarRepository
    {
        void AddCar(Car car);
        Car GetCar(string model);
        List<Car> GetCars();
        void DeleteCar(string model);
    }
    public class CarRepository : ICarRepository
    {
        private readonly List<Car> cars = new List<Car>()
        {
            new Car(){Make="Hundai",Model="i10",Year=2014,Price=1200000},
            new Car(){Make="Maruti",Model="Alto",Year=2010,Price=180000},

        };
        public void AddCar(Car car)
        {
            try
            {
                cars.Add(car);
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteCar(string model)
        {
            try
            {
                Car ?car = GetCar(model);
                cars.Remove(car); //remove car
            }
            catch (Exception)
            {

                throw;
            }
        }

        public Car? GetCar(string model)
        {
            try
            {
                return cars.SingleOrDefault(car => car.Model == model); //retrun car with specific model
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<Car> GetCars()
        {
            try
            {
                return cars;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
