﻿namespace HandsOnAPIUsingModels.Models
{
    public class Car
    {
        public  string? Make { get; set; }
        public string? Model { get;set; }
        public int Year { get; set; }
        public double Price { get; set; }
    }
}
